export const mockNutritionPlan = {
  summary: {
    plan_goal: 'weight_loss',
    daily_calories: 1850,
    daily_macros: {
      protein_g: 135,
      carbs_g: 190,
      fat_g: 58,
    },
  },
  days: [
    {
      day_number: 1,
      title: 'Balanced Starter Day',
      meals: [
        {
          meal_id: 'breakfast-1',
          meal_type: 'Breakfast',
          title: 'Greek yogurt power bowl',
          cost_estimation: 'low',
          prep_time_minutes: 10,
          tags: ['quick', 'high-protein'],
          foods: [
            {
              food_id: 'yogurt',
              name: 'Greek yogurt',
              quantity: '1 cup',
              substitutions: [{ name: 'Labneh', quantity: '1 cup' }],
            },
            {
              food_id: 'berries',
              name: 'Mixed berries',
              quantity: '1/2 cup',
              substitutions: [{ name: 'Apple slices', quantity: '1 medium' }],
            },
          ],
          meal_alternatives: [
            {
              meal_id: 'breakfast-1-alt',
              meal_type: 'Breakfast',
              title: 'Egg and avocado toast',
              cost_estimation: 'medium',
              prep_time_minutes: 12,
              tags: ['quick', 'balanced'],
              foods: [
                { food_id: 'eggs', name: 'Boiled eggs', quantity: '2', substitutions: [] },
                { food_id: 'toast', name: 'Whole grain toast', quantity: '1 slice', substitutions: [] },
              ],
              meal_alternatives: [],
            },
          ],
        },
        {
          meal_id: 'lunch-1',
          meal_type: 'Lunch',
          title: 'Chicken quinoa salad',
          cost_estimation: 'medium',
          prep_time_minutes: 20,
          tags: ['balanced', 'meal-prep'],
          foods: [
            {
              food_id: 'chicken',
              name: 'Grilled chicken breast',
              quantity: '150 g',
              substitutions: [{ name: 'Tuna', quantity: '1 can' }],
            },
            {
              food_id: 'quinoa',
              name: 'Cooked quinoa',
              quantity: '3/4 cup',
              substitutions: [{ name: 'Brown rice', quantity: '3/4 cup' }],
            },
          ],
          meal_alternatives: [],
        },
      ],
    },
    {
      day_number: 2,
      title: 'Simple Routine Day',
      meals: [
        {
          meal_id: 'dinner-2',
          meal_type: 'Dinner',
          title: 'Salmon rice plate',
          cost_estimation: 'medium',
          prep_time_minutes: 25,
          tags: ['omega-3', 'balanced'],
          foods: [
            {
              food_id: 'salmon',
              name: 'Baked salmon',
              quantity: '140 g',
              substitutions: [{ name: 'Chicken thigh', quantity: '150 g' }],
            },
            {
              food_id: 'rice',
              name: 'Steamed rice',
              quantity: '3/4 cup',
              substitutions: [{ name: 'Sweet potato', quantity: '1 medium' }],
            },
          ],
          meal_alternatives: [],
        },
      ],
    },
  ],
  shopping_list: [
    'Greek yogurt',
    'Mixed berries',
    'Chicken breast',
    'Quinoa',
    'Salmon',
    'Rice',
    'Leafy greens',
  ],
  plan_tags: ['frontend-demo', 'mock-data', 'balanced'],
  fallback_message: 'This is demo data for running the frontend without the backend.',
};
