# Data Diet Frontend Only

This folder contains only the React/Vite frontend. It does not include the Django backend.

## Run the frontend

```bash
npm install
npm run dev
```

Open the URL shown by Vite, usually:

```text
http://localhost:5173
```

## Backend-free demo mode

The frontend uses mock data by default, so login, register, saved plans, and AI plan generation can be demonstrated without starting the backend.

To connect it to the real backend later, create a `.env` file and set:

```bash
VITE_USE_MOCK_API=false
VITE_API_BASE_URL=http://localhost:8000/api/
```
