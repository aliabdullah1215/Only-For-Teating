import { getStoredUser, setAuthStorage } from './authStorage';

const mockDelay = 250;

function wait() {
  return new Promise((resolve) => {
    window.setTimeout(resolve, mockDelay);
  });
}

function buildUser(payload) {
  const username = payload.username || 'demo';
  return {
    id: 1,
    username,
    email: payload.email || `${username}@example.com`,
    role: payload.role === 'doctor' ? 'doctor' : 'client',
  };
}

export async function registerMockUser(payload) {
  await wait();
  const user = buildUser(payload);
  localStorage.setItem('data_diet_mock_registered_user', JSON.stringify(user));
  return user;
}

export async function loginMockUser(credentials) {
  await wait();
  const storedUser = localStorage.getItem('data_diet_mock_registered_user');
  const user = storedUser ? JSON.parse(storedUser) : buildUser(credentials);
  const access = 'mock-access-token';
  const refresh = 'mock-refresh-token';

  setAuthStorage({ access, refresh, user });

  return { access, refresh, user };
}

export async function fetchMockCurrentUser() {
  await wait();
  const user = getStoredUser();

  if (!user) {
    throw new Error('No mock user is signed in.');
  }

  return user;
}

export async function refreshMockAccessToken() {
  await wait();
  return { access: 'mock-access-token' };
}
