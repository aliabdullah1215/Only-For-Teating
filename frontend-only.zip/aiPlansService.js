import api from '../../../api/axios';
import { mockNutritionPlan } from './mockPlanData';

const useMockApi = import.meta.env.VITE_USE_MOCK_API !== 'false';

function cloneMockPlan() {
  return JSON.parse(JSON.stringify(mockNutritionPlan));
}

export async function generateAiPlan(normalizedProfile) {
  if (useMockApi) {
    return {
      id: 'mock-plan-1',
      goal: normalizedProfile.goal?.type || 'weight_loss',
      focus: normalizedProfile.preferences?.diet_type || 'balanced',
      created_at: new Date().toISOString(),
      plan: cloneMockPlan(),
    };
  }

  const response = await api.post('ai-plans/generate/', normalizedProfile);
  return response.data;
}

export async function getMySavedPlans() {
  if (useMockApi) {
    return [
      {
        id: 'mock-plan-1',
        goal: 'Weight loss',
        focus: 'Balanced nutrition',
        status: 'active',
        created_at: new Date().toISOString(),
        note: 'Demo saved plan shown when the frontend runs without the backend.',
      },
    ];
  }

  const response = await api.get('ai-plans/');
  return response.data;
}

export async function getSavedPlanById(planId) {
  if (useMockApi) {
    return {
      id: planId,
      goal: 'Weight loss',
      focus: 'Balanced nutrition',
      created_at: new Date().toISOString(),
      plan_content: cloneMockPlan(),
    };
  }

  const response = await api.get(`ai-plans/${planId}/`);
  return response.data;
}
